﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Arena.Core.Entities;
using Arena.Infrastructure.Data.Seed;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Arena.Infrastructure.Data
{
    public static class ArenaContextSeed
    {
        public static async Task SeedCustomersAsync(IServiceProvider services)
        {
            var context = services.GetService<ArenaContext>();
            var customers = context.Set<Customer>();
            var orders = context.Set<Order>();
            bool anyCustomer = await customers.AnyAsync();
            bool anyOrder = await orders.AnyAsync();

            if (!anyCustomer)
            {
                await customers.AddRangeAsync(CustomerSeedData.GetCustomers());
            }

            if (!anyOrder)
            {
                await orders.AddRangeAsync(OrderSeedData.GetOrders());
            }


            await context.SaveChangesAsync();
        }
    }
}
