﻿using System;

namespace Arena.Infrastructure.Data.Seed
{
    public static class CommonSeedData
    {
        public static DateTime Date => new DateTime(2018, 10, 11);

    }
}
