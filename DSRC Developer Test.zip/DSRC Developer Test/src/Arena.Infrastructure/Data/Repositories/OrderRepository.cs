﻿using Arena.Core.Entities;
using Arena.Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arena.Infrastructure.Data.Repositories
{
    public class OrderRepository : Repository<Order>, IOrderRepository
    {
        protected readonly ArenaContext DbContext;
        public OrderRepository(ArenaContext dbContext): base (dbContext)
        {
            DbContext = dbContext;
        }

        public async Task<IEnumerable<Order>> GetOrdersWithCustomerAsync()
        {
            try
            {
                return await DbContext.Orders.Include(b => b.Customer).Select(a => a).ToListAsync();

            }
            catch(Exception error)
            {
                throw error;
            }
        }
    }
}
