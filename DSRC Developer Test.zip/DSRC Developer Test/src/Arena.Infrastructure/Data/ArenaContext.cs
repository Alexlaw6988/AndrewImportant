﻿using Arena.Core.Entities;
using Arena.Infrastructure.Data.Seed;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;

namespace Arena.Infrastructure.Data
{
    public class ArenaContext : DbContext
    {
        public ArenaContext(DbContextOptions<ArenaContext> options) : base(options)
        {
        }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Order>()
                   .HasOne<Customer>(c => c.Customer)
                   .WithMany(ad => ad.Orders)
                   .HasForeignKey(f => f.CustomerId);
        }
    }
}
