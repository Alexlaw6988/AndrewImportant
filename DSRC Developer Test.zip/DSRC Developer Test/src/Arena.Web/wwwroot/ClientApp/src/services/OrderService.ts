import { OrderModel } from '@/types';
import { ApiUrls } from '@/constants/Api.urls';
import {ApiBaseService as HTTP} from '@/http-common/http-common'

export const OrderService = {

    GetAllOrders(){
        return HTTP.get(ApiUrls.GetAllOrders);
    },
    GetOrderById(Id : any ){
        return HTTP.get(`${ApiUrls.GetOrderById}/${Id}`);
    },
    CreateOrder(Order : OrderModel){
        HTTP.post(ApiUrls.CreateOrder,Order);
    },
    UpdateOrder(Order : OrderModel){
        HTTP.put(ApiUrls.UpdateOrder,Order);
    },
    DeleteOrder(Order : OrderModel){
        HTTP.put(ApiUrls.DeleteOrder,Order);
    }
};
