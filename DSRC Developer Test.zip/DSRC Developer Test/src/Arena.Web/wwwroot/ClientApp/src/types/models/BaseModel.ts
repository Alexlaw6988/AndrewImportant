
export interface BaseModel {
    id: number;
    createdDate:string;
    modifiedDate:string;
}
