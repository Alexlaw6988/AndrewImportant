import { BaseModel } from '../BaseModel';

export interface CustomerModel extends BaseModel{
    firstName: string;
    lastName: string;
    dateOfBirth: string;
}
