import Vue from 'vue';
import Router from 'vue-router';
import { RouteConstants } from '@/constants/Route.constants';


Vue.use(Router);
export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: RouteConstants.DefaultLayoutRoute.path,
      component: () => import('@/layouts/default.layout.vue'),
      children: [{
        path: RouteConstants.HomeRoute.path,
        name: RouteConstants.HomeRoute.name,
        component: () => import('./views/Home.vue')
      },
      {
        path: RouteConstants.CustomerRoute.path,
        name: RouteConstants.CustomerRoute.name,
        component: () => import('./views/customer/Customers.vue')
      },
      {
        path: RouteConstants.OrderRoute.path,
        name: RouteConstants.OrderRoute.name,
        component: () => import('./views/order/Orders.vue')
      }]

    }

  ],
});
