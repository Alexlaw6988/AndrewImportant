<template>
  <div class="card">
    <div class="card-header font-weight-bold bg-light">
    {{ PageConfiguration.PageHeader }}
    </div>
    <div class="card-body">
      
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import Grid from "@/components/Grid.vue";
@Component({
  name: "Home"
})
export default class Home extends Vue {}
</script>
