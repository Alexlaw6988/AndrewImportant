<template>
  <div class="card">
    <div class="card-body">
      <div>
        <form novalidate >
            <p class="text-danger" v-if="errors.length">
                <b>Please correct the following error(s):</b>
                    <ul>
                        <li v-for="(error,index) in errors" :key="index+error">{{ error }}</li>
                    </ul>
            </p>
          <div class="form-group">
            <label for="firstName">First Name</label>
            <input
              type="Text"
              class="form-control"
              id="firstName"
              placeholder="Enter First Name"
              v-model="customerDetail.firstName"
            />
          </div>
          <div class="form-group">
            <label for="lastName">Last Name</label>
            <input
              type="Text"
              class="form-control"
              id="lastName"
              placeholder="Enter Last Name"
              v-model="customerDetail.lastName"
            />
          </div>
          <div class="form-group">
            <label for="dateOfBirth">Date of Birth</label>
            <input
              type="text"
              class="form-control"
              id="dateOfBirth"
              v-bind:placeholder="DateOfBirthFormat"
              v-model="customerDetail.dateOfBirth"
            />
          </div>

          <button type="button" class="btn btn-primary" @click="createCustomer()">Submit</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { CustomerModel } from "../../types";
import { CustomerService } from "../../services/CustomerService";
import moment from "moment";
import { ApplicationConstants , RouteConstants } from "@/constants";

@Component({
  name: "CreateCustomer",
  props:["onCustomerCreationSuccess"]
  
})
export default class Customers extends Vue {
  customerDetail: any={};
  errors : any = [];
  DateOfBirthFormat : string = ApplicationConstants.UiDateFormat;

  createCustomer() {
      if(this.validateCustomer()){
        var customerModelData  = this.createCustomerModel();
    CustomerService.CreateCustomer(customerModelData)
      .then(res => {
          this.$emit('onCustomerCreationSuccess');            
      })
      .catch(error => {
        console.error(error);
      });
      }
       
  }
validateCustomer(){
 if(this.customerDetail.firstName && this.customerDetail.lastName && this.customerDetail.dateOfBirth && moment(this.customerDetail.dateOfBirth).isValid()) {
        return true;
      }
      this.errors = [];

      if (!this.customerDetail.firstName) {
        this.errors.push('First Name is required.');
      }
      if (!this.customerDetail.lastName) {
        this.errors.push('Last Name is required.');
      }
      if (!(this.customerDetail.dateOfBirth && moment(this.customerDetail.dateOfBirth).isValid())){
        this.errors.push(`Date is required and enter in ${ApplicationConstants.UiDateFormat} format`);
      }
     return false;
}
      
       
  


  createCustomerModel(){
      return {
      firstName: this.customerDetail.firstName,
      lastName: this.customerDetail.lastName,
      dateOfBirth: moment(
      this.customerDetail.dateOfBirth
    ).format(ApplicationConstants.ApiDateFormat),
      id: 0,
      createdDate: moment().format(ApplicationConstants.ApiDateFormat),
      modifiedDate: moment().format(ApplicationConstants.ApiDateFormat)
    };
  }

  
}
</script>
