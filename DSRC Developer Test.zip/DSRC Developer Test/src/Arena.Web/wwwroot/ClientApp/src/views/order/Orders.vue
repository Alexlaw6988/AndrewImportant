<template>
  <div class="card">
    <div class="card-header font-weight-bold bg-light">
      {{ PageConfiguration.PageHeader }}
    </div>
    <div class="card-body">     
      <div>
        <Grid
          :gridTitle="PageConfiguration.OrdersGridTitle"
          :configurations="PageConfiguration.OrdersGridConfigurations"
          :data="ordersList"
          :searchColumns="PageConfiguration.searchColumns"
        ></Grid>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import Grid from "@/components/Grid.vue";
import { OrderModel } from "../../types";
import { OrderService } from "@/services/OrderService";
@Component({
  name: "Orders",
  components: { Grid }
})
export default class Orders extends Vue {
  ordersList: OrderModel[] = [];

  created() {
    this.GetAllOrders();
  }

  GetAllOrders() {
    OrderService.GetAllOrders()
      .then(res => {
        this.ordersList = res.data;
        this.processOrdersList();
      })
      .catch(error => {
        console.log(error);
      });
  }

  processOrdersList(){
      this.ordersList.forEach((order)=>{
          if(order.customer)
          order.customerName = `${order.customer.firstName} ${order.customer.lastName}`;
      })
  }
}
</script>
