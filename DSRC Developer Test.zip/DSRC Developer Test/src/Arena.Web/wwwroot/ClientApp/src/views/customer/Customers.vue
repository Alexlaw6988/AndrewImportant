<template>
  <div class="card">
    <div class="card-header font-weight-bold bg-light">
      {{ PageConfiguration.PageHeader }}
    </div>
    <div class="card-body">
      <div>
        <div class="container-fluid mb-2">
          <div>
            <b-button variant="success" v-b-modal.add-customer-modal
              >Add new Customer</b-button
            >
          </div>
        </div>
      </div>
      <div>
        <Grid
          :gridTitle="PageConfiguration.CustomersGridTitle"
          :actions="PageConfiguration.CustomersGridActions"
          @onView="onCustomerViewClick"
          :configurations="PageConfiguration.CustomersGridConfigurations"
          :data="customersList"
        ></Grid>
      </div>
    </div>
    <div>
      <b-modal
        id="customer-view-modal"
        centered
        :title="CustomerName"
        :hide-footer="true"
        class="modal fade"
        ref="customer-view-modal"
        size="lg"
      >
        <DynamicView
          :configurations="PageConfiguration.CustomersGridConfigurations"
          :data="customerDetail"
        >
        </DynamicView>
      </b-modal>

      <b-modal
        id="add-customer-modal"
        centered
        :title="PageConfiguration.CreateCustomersTitle"
        :hide-footer="true"
        class="modal fade"
        size="lg"
        ref="add-customer-modal"
      >
        <div>
          <CreateCustomer
            @onCustomerCreationSuccess="onCustomerCreationSuccess"
          >
          </CreateCustomer>
        </div>
      </b-modal>
      
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { CustomerModel } from "../../types";
import { CustomerService } from "../../services/CustomerService";
import Grid from "@/components/Grid.vue";
import DynamicView from "@/components/DynamicView.vue";
import CreateCustomer from "@/views/customer/CreateCustomer.vue";

import { ApplicationConstants } from "@/constants/Application.constants";
@Component({
  name: "Customers",
  components: { Grid, DynamicView, CreateCustomer }
})
export default class Customers extends Vue {
  customersList: CustomerModel[] = [];
  customerDetail: any = {};
  created() {
    this.GetAllCustomers();
  }

  get CustomerName() {
    if (this.customerDetail)
      return `${this.customerDetail.firstName} ${this.customerDetail.lastName}`;
  }

  GetAllCustomers() {
    CustomerService.GetAllCustomers()
      .then(res => {
        this.customersList = res.data;
      })
      .catch(error => {
        console.log(error);
      });
  }

  onCustomerViewClick(model: CustomerModel) {
    this.customerDetail = model;
    this.$refs["customer-view-modal"].show();
  }

  onCustomerCreationSuccess() {
    this.$refs["add-customer-modal"].hide();
    this.GetAllCustomers();
    console.log("customerModelData");
    this.$bvModal
      .msgBoxOk("Customer created successfully", {
        title: "Confirmation",
        size: "sm",
        buttonSize: "sm",
        okVariant: "success",
        headerClass: "p-2 border-bottom-0",
        footerClass: "p-2 border-top-0",
        centered: true,
        backdrop: false
      })
      .then(value => {})
      .catch(error => {
        console.log(error);
      });
  }
}
</script>
<style type="text/css">

.modal-backdrop {  
  opacity: 0.6 !important;
}
</style>
