import { Vue, Component } from 'vue-property-decorator'
import { PageConfigurationService } from "@/services/PageConfigurationService";

@Component
export default class PageConfigurationMixin extends Vue {
    public PageConfiguration: any = {};
    created() {
        if (this.$options.name)
            this.getPageConfigurations(this.$options.name);
    }
    getPageConfigurations(ComponentName: string) {
        PageConfigurationService.getPageConfigurations(ComponentName)
            .then(res => {
                this.PageConfiguration = res.data;
            })
            .catch(error => {
                console.error(error);
            });
    }
}
