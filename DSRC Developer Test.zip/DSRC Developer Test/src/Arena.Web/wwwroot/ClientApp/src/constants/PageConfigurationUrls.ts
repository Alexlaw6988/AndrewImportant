export const PageConfigurationUrls = Object.freeze({
    Header: 'JsonConfigurations/headerComponentConfigurations.json',
    NavBar: 'JsonConfigurations/navBarComponentConfigurations.json',
    Home: 'JsonConfigurations/homePageConfigurations.json',
    Customers: 'JsonConfigurations/customersPageConfigurations.json',
    Orders:'JsonConfigurations/ordersPageConfigurations.json',
    Grid:'JsonConfigurations/gridComponentConfigurations.json'
});
