<template>
  <div id="DynamicView" class="container-fluid">
    <div class="card">
      <div class="card-body">
        <div
          v-for="(configuration, index) in configurations"
          :key="configuration.key + index"
        >
          <h6><strong>{{configuration.header}}</strong> : <span v-if="configuration.type == 'date'"
                      >{{ data[configuration.key] | date }}
                    </span>
                    <span v-else> {{ data[configuration.key] }}</span> </h6>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import date from "@/filters/dateFilter";
@Component({
  name: "DynamicView",
  props: ["configurations", "data"],
  filters: { date }
})
export default class DynamicView extends Vue {}
</script>
