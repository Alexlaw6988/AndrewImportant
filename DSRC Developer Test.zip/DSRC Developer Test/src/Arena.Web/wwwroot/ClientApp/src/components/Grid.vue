<template>
  <div id="grid" class="container-fluid">
    <div class="card">
      <div class="card-header font-weight-bold bg-light" v-if="gridTitle">
        {{ gridTitle }}
      </div>
      <div class="card-body">
        <div class="form-group" v-if="searchColumns">
          <input
            class="form-control col-md-3"
            type="text"
            placeholder="Search"
            aria-label="Search"
            v-model="searchText"
          />
        </div>
        <div>
          <table class="table table-striped">
            <thead class="bg-info text-white">
              <tr>
                <th
                  v-for="(configuration, index) in configurations"
                  :key="index + 'header'"
                  scope="col"
                >
                  {{ configuration.header }}
                </th>
                <th v-if="actions">Actions</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="!filteredData || filteredData.length < 1">
                No Records Found
              </template>
              <template v-else>
                <tr
                  v-for="(row, rowIndex) in filteredData"
                  :key="'row' + rowIndex"
                >
                  <td
                    v-for="(configuration, columnIndex) in configurations"
                    :key="configuration.key + rowIndex + columnIndex"
                  >
                    <span v-if="configuration.type == 'date'"
                      >{{ row[configuration.key] | date }}
                    </span>
                    <span v-else> {{ row[configuration.key] }}</span>
                  </td>
                  <td v-if="actions">
                    <div
                      v-for="(action, actionIndex) in actions"
                      :key="actionIndex + rowIndex + action"
                    >
                      <button
                        type="button"
                        class="btn"
                        v-bind:class="{
                          'btn-danger': action == 'delete',
                          'btn-success': action == 'view',
                          'btn-warning': action == 'edit'
                        }"
                        @click="
                          onActionButtonClick(PageConfiguration.eventOnActions[action], row)
                        "
                      >
                        {{ action }}
                      </button>
                    </div>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import date from "@/filters/dateFilter";

@Component({
  name: "Grid",
  props: [
    "configurations",
    "data",
    "gridTitle",
    "searchColumns",
    "actions",
    "onEdit",
    "onView",
    "onDelete"
  ],
  filters: { date }
})
export default class Grid extends Vue {
  searchText: string = "";

  get filteredData() {
    if (!this.$props.searchColumns) {
      return this.$props.data;
    }
    return this.$props.data.filter((rowData: any) => {
      let flag = false;
      this.$props.searchColumns.forEach((key: any) => {
        if (rowData[key]) {
          flag =
            flag ||
            rowData[key]
              .toLowerCase()
              .startsWith(this.searchText.toLowerCase());
        }
      });
      return flag;
    });
  }
  onActionButtonClick(action: string, model: any) {
    this.$emit(action, model);
  }
}
</script>
