import { Vue } from "vue-property-decorator";
import moment from "moment";
import { ApplicationConstants } from "@/constants";

 const dateFilter = function (value:any,dateFormat:string=ApplicationConstants.UiDateFormat) {
     return moment(value).format(dateFormat);
 }

 export default dateFilter;