import Order from './components/order/AppOrder'
import Customer from './components/customer/AppCustomer'

export const routes = [
  { path: '/order', component: Order },
  { path: '/customer', component: Customer },
  { path: '/', redirect: '/order' }
]
