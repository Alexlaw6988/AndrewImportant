<template>
    <div id="app" class="container">
        <div id="header-content">
            <app-header></app-header>
        </div>
        <div id="main-content">
            <router-view></router-view>
        </div>
    </div>
</template>

<script>
export default {
  name: 'App',
}
</script>
<style lang="scss">
    @import "src/assets/styles/_global.scss";
</style>
