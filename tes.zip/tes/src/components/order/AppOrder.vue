<template>
  <div>
    <vue-table :endpoint="orderAPI"
               :columns="orderFields"
               :form-fields="{
               customerId: '',
               orderNumber: '',
               value : '',
               details : ''
               }"
               @edited ="onEdit">
        <template v-slot:input-fields="{formdata}">
            <label v-if="customers.length === 0" class="err-text">
                Please add Customer information
            </label>
            <b-form-group id="order-customer-group" label="Customer" label-for="customer-list">
                <select id="customer-list" class="form-control custom-select" v-model="formdata.customerId" :disabled="isEdit" required>
                    <option hidden disabled selected value> --Select a Customer-- </option>
                    <option v-for="cust in customers" :key="cust.id" :value="cust.id">
                        {{ cust.firstName + " " + cust.lastName }}
                    </option>
                </select>
            </b-form-group>
            <b-form-group id="order-number-group" label="Order Number" label-for="order-number">
                <b-form-input id="order-number"
                              v-model="formdata.orderNumber"
                              :disabled="isEdit"
                              required
                              placeholder="Enter Order Number">

                </b-form-input>
            </b-form-group>
            <b-form-group id="order-value-group" label="Order Value" label-for="order-value">
                <b-form-input id="order-value"
                              v-model="formdata.value"
                              :type="'number'"
                              required
                              min="1"
                              max="100000"
                              placeholder="Enter Order Value">

                </b-form-input>
            </b-form-group>
            <b-form-group id="order-detail-group" label="Details" label-for="order-detail">
                <b-form-input id="order-detail"
                              v-model="formdata.details"
                              required
                              placeholder="Enter Order Details">

                </b-form-input>
            </b-form-group>
        </template>
    </vue-table>
  </div>
</template>
<script>
import axios from 'axios'
import swal from 'sweetalert2'
import vueTable from '../_shared/VueTable.vue'

export default {
  components: {
    'vue-table': vueTable
  },
  data () {
      return {
      orderAPI: process.env.VUE_APP_ORDERAPI + 'order',
      customerAPI: process.env.VUE_APP_ORDERAPI + 'customer',
      isEdit: false,
      orders: [],
      customers: [],
      orderFields: [
        {
          key: 'customerName',
          sortable: true
        },
        {
          key: 'orderNumber',
          sortable: true
        },
        {
          key: 'value'
        },
        {
          key: 'details'
        },
        {
          key: 'action'
        }]
    }
  },
  methods: {
    onEdit (value) {
      this.isEdit = value
    },
    getCustomers () {
        axios.get(this.customerAPI)
        .then(response => (this.customers = response.data))
        .catch(function (error) {
            swal.fire('Error Occured on getting customers. Please try again after sometime!', error);
        })
    }
  },
  computed: {

  },
  watch: {

  },
  created () {
    this.getCustomers()
  }
}
</script>
<style lang="scss" scoped>
    @import "../../assets/styles/_global.scss";
</style>
