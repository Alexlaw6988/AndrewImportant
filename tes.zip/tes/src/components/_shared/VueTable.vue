<template>
  <div>
    <div class="row table-header">
        <div class="col-xs-2 col-md-1">
            <b-button @click="createItem" class="header-btn">Create</b-button>
        </div>
      <div class="col-xs-2 col-sm-4">
        <input type="text" class="form-control dv-header-input"
               placeholder="Enter Your Search Text here" v-model="search_text">
      </div>
    <div class="col-xs-8 col-sm-6 recordCount">
        <label>No. of records: &nbsp; {{tableData.length}}</label>
    </div>
    </div>
    <hr />
    <b-table striped hover sticky-header :items="tableData" :fields="columns" :filter="search_text">
      <template #cell(dateOfBirth)="data">
        {{ data.item.dateOfBirth | formatDate }}
      </template>
      <template #cell(action)="data">
        <b-button @click="editItem(data.item)" class="tbl-btn-primary">Edit</b-button>&nbsp;
        <b-button @click="deleteItem(data.item)" v-b-modal="'edit-modal'" class="tbl-btn-danger">Delete</b-button>
      </template>
    </b-table>

    <b-modal v-model="modalShow" :title="formTitle" hide-footer>
      <b-form @submit.prevent="save">
        <slot :formdata="editedItem" name="input-fields">
        </slot>
        <b-button class="tbl-btn-secondary" @click="close">Cancel</b-button>&nbsp;
        <b-button type="submit" class="tbl-btn-primary">Submit</b-button>
      </b-form>
    </b-modal>
  </div>
</template>

<script>
    import axios from 'axios'
    import swal from 'sweetalert2'

export default {
  props: ['endpoint', 'columns', 'formFields'],
  data () {
      return {
      editedItem: this.formFields,
      modalShow: false,
      editedIndex: -1,
      tableData: [],
      search_text: ''
    }
  },
  computed: {
    formTitle () {
      return this.editedIndex === -1 ? 'New Item' : 'Edit Item'
    }
  },
methods: {
    getItems() {
        axios.get(this.endpoint)
            .then(response => {
                this.tableData = response.data
                console.log(this.tableData)
        })
        .catch(function (error) {
            swal.fire('Error Occured. Please try again after sometime!', error);
        })
    },
    createItem() {
      this.modalShow = true
      this.editedItem = Object.assign({}, this.formFields)
      this.editedIndex = -1
      this.$emit('edited', false)
    },
    editItem (item) {
      this.modalShow = true
      this.editedIndex = this.tableData.indexOf(item)
      this.editedItem = Object.assign({}, item)
      this.$emit('edited', true)
    },
    deleteItem (item) {
      const index = this.tableData.indexOf(item)
        this.editedItem = Object.assign({}, item)
        swal.fire({
            title: 'Are you sure you want to delete this item?',
            showDenyButton: true,
            confirmButtonText: 'Delete',
            denyButtonText: `Don't Delete`,
        }).then((result) => {
            if (result.isConfirmed) {
                if (this.tableData.splice(index, 1)) {
                    axios.delete(this.endpoint + '/' + this.editedItem.id, { data: this.editedItem }).then(() => {
                        this.getItems()
                        swal.fire('Success', 'Deleted record')
                    }).catch(error => {
                        swal.fire('Error Occured. Please try again', error);
                    })
                }
            } 
        })
    },
    close () {
      this.modalShow = false
      setTimeout(() => {
        this.editedItem = Object.assign({}, this.formFields)
        this.editedIndex = -1
      }, 300)
    },
    save () {
      if (this.editedIndex > -1) {
        axios.put(this.endpoint + '/' + this.editedItem.id, this.editedItem).then(() => {
            this.getItems()
            this.close()
            swal.fire('Success', 'Updated record');
        }).catch(error => {
            console.log(error);
            swal.fire('Error Occured. Please try again', error);
        })
      }
      else {
          axios.post(this.endpoint, this.editedItem).then(() => {
              this.getItems()
              this.close()
           swal.fire('Success','Created new record');
          }).catch(error => {
              console.log(error);
            swal.fire('Error Occured',error);
        })
      }
    }
  },
created() {
    this.getItems();
}
}
</script>
<style lang="scss" scoped>
@import "../../assets/styles/_global.scss";
</style>
