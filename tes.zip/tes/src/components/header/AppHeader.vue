<template>
  <section>
    <b-navbar toggleable="lg" type="dark" variant="dark">
      <b-navbar-brand href="#">Order Tracker</b-navbar-brand>

      <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

      <b-collapse id="nav-collapse" is-nav>
        <b-navbar-nav>
          <b-nav-item>
            <router-link to="/order" class="nav-link" active-class="active"><a>Orders</a></router-link>
          </b-nav-item>
          <b-nav-item>
            <router-link to="/customer" class="nav-link" active-class="active"><a>Customers</a></router-link>
          </b-nav-item>
        </b-navbar-nav>
      </b-collapse>
    </b-navbar>
  </section>
</template>
<script>
export default {
  data () {
    return {
      title: 'Order Tracker'
    }
  },
  methods: {

  },
  computed: {

  },
  watch: {

  }
}
</script>
<style lang="scss">
  @import "../../assets/styles/_global.scss";
</style>
