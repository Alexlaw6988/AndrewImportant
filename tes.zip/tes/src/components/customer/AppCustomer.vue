<template>
  <section>
    <div>
      <vue-table :endpoint="customerAPI"
                 :columns="customerFields"
                 :formFields="{
                   firstName : '',
                   lastName : '',
                   dateOfBirth : ''
                 }">
        <template v-slot:input-fields="{formdata}">
          <b-form-group id="customer-fn-group" label="First Name" label-for="f-name">
            <b-form-input id="f-name"
                          v-model="formdata.firstName"
                          required
                          placeholder="Enter Customer FirstName">

            </b-form-input>
          </b-form-group>
          <b-form-group id="customer-ln-group" label="Last Name" label-for="l-name">
            <b-form-input id="l-name"
                          v-model="formdata.lastName"
                          required
                          placeholder="Enter Customer LastName">

            </b-form-input>
          </b-form-group>
          <b-form-group id="customer-dob-group" label="Date of Birth" label-for="dob">
            <b-form-datepicker id="dob" required
                               v-model="formdata.dateOfBirth"
                               max="maxDate"></b-form-datepicker>
          </b-form-group>
        </template>
      </vue-table>
    </div>
  </section>
</template>
<script>
import VueTable from '../_shared/VueTable.vue'
export default {
  components: {
    'vue-table': VueTable
  },
  data () {
      return {
          maxDate: new Date(),
          customerAPI: process.env.VUE_APP_ORDERAPI +'customer',
      customerFields: [
        {
          key: 'firstName',
          sortable: true
        },
        {
          key: 'lastName',
          sortable: true
        },
        {
          key: 'dateOfBirth'
        },
        {
          key: 'action'
        }
      ]
    }
  },
  methods: {

  },
  computed: {
  },
  watch: {

  }
}
</script>
<style lang="scss" scoped>
  @import "../../assets/styles/_global.scss";
</style>
