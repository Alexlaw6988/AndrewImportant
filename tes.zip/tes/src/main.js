import Vue from 'vue'
import App from './App'

import 'jquery/src/jquery.js'
import 'popper.js/dist/popper.js'
import 'bootstrap/dist/js/bootstrap.min.js'
import 'bootstrap/dist/css/bootstrap.min.css'
import VueSweetalert2 from 'vue-sweetalert2';

import VueRouter from 'vue-router'
import { routes } from './routes'

import AppHeader from './components/header/AppHeader'
import AppCustomer from './components/customer/AppCustomer'
import AppOrder from './components/order/AppOrder'
import AppFooter from './components/footer/AppFooter'
import Bootstrapvue from 'bootstrap-vue'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import moment from 'moment'

Vue.config.productionTip = false

Vue.component('app-header', AppHeader)
Vue.component('app-customer', AppCustomer)
Vue.component('app-order', AppOrder)
Vue.component('app-Footer', AppFooter)

Vue.use(VueSweetalert2);
Vue.use(VueRouter)
Vue.use(Bootstrapvue)

const router = new VueRouter({
    routes,
    mode: 'history'
})

new Vue({
    render: h => h(App),
    router,
}).$mount('#app')

Vue.filter('formatDate', function (value) {
    if (value) {
        return moment(String(value)).format('DD/MM/YYYY')
    }
})