﻿using Arena.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Arena.Core.Interfaces
{
    public interface IOrderService
    {
        Task<IEnumerable<Order>> GetOrdersAsync();
        Task<Order> GetOrderByIdAsync(int id);
        Task<Order> AddOrderAsync(Order order);
        Task<Order> UpdateOrderAsync(Order order);
        Task<Order> DeleteOrderAsync(Order order);
    }
}
