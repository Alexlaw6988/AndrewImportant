﻿using Arena.Core.Interfaces;
using Arena.Core.Services;
using Arena.Infrastructure.Data;
using Arena.Infrastructure.Data.Repositories;
using Microsoft.Extensions.DependencyInjection;

namespace Arena.Web.Extensions
{
    public static class StartupExtensions
    {
        public static void RegisterServices(this IServiceCollection services)
        {
            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
            services.AddScoped(typeof(IOrderRepository), typeof(OrderRepository));
            services.AddScoped<ICustomerService, CustomerService>();
            services.AddScoped<IOrderService, OrderService>();
        }
    }
}
