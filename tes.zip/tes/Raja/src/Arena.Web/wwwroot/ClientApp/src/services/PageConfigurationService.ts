import {ApiBaseService} from '@/http-common/http-common'
import { PageConfigurationUrls} from "@/constants/PageConfigurationUrls";

export const PageConfigurationService = {
    
    getPageConfigurations:function (componentName:string){
        return  ApiBaseService.get((PageConfigurationUrls as any)[componentName]);
      }
};
