export const ApiUrls = Object.freeze({
    GetAllCustomers : '/api/Customer/customers',
    GetCustomerById : "/api/Customer/customer",
    CreateCustomer:"/api/Customer/createCustomer"  ,
    UpdateCustomer:"/api/Customer/updateCustomer",
    DeleteCustomer:"/api/Customer/deleteCustomer",

    GetAllOrders : '/api/Order/orders',
    GetOrderById : "/api/Order/order",
    CreateOrder:"/api/Order/createOrder"  ,
    UpdateOrder:"/api/Order/updateOrder",
    DeleteOrder:"/api/Order/deleteOrder",
});
