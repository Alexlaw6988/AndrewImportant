<template>
  <div class="collapse navbar-collapse" id="navbar">
    <ul class="navbar-nav ml-auto">
      <li
        v-for="route in PageConfiguration.Routes"
        :key="route"
        class="nav-item h6 mb-0 py-1 px-1"
      >
        <router-link :to="Routes[route].path" class="nav-link">{{
          Routes[route].name
        }}</router-link>
      </li>
    </ul>
  </div>
</template>
<script lang="ts">
import { Component, Vue} from "vue-property-decorator";
import { RouteConstants } from "@/constants/Route.constants";

@Component({
  name: "NavBar",
})
export default class NavBar extends Vue {
    public Routes:any = RouteConstants;
  
}
</script>
