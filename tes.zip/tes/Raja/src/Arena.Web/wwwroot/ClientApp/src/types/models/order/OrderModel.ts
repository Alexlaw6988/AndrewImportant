import { CustomerModel } from '../customer';
import { BaseModel } from '../BaseModel';

export interface OrderModel extends BaseModel{
    orderNumber: string;
    value: number;
    details: string;
    customerId: number;
    customerName: string;
    customer: CustomerModel;  
}
