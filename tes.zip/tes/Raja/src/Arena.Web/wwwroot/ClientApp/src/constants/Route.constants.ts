export const RouteConstants = Object.freeze({
    DefaultLayoutRoute:{
        path: '/',
        name: 'DefaultLayout',
    },
    HomeRoute : {
        path: '/',
      name: 'Home',
    },
    CustomerRoute : {
        path: '/customers',
      name: 'Customers'
    },
    OrderRoute : {
      path: '/orders',
    name: 'Orders'
  }
});
