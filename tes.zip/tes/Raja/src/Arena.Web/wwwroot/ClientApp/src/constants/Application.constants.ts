export const ApplicationConstants = Object.freeze({
    ApiDateFormat : 'YYYY-MM-DDTHH:mm:ss.SSS',
    UiDateFormat : 'MM-DD-YYYY',
    
});
