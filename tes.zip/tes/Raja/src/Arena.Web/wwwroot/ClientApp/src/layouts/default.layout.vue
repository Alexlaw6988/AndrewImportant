<template>
  <div id="default-layout">
    <Header></Header>
    <div class="mt-3  container-fluid pl-5 pr-5">
      <div class="card">
        <router-view />
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import Header from "@/components/Header.vue";
@Component({
  components: { Header }
})
export default class DefaultLayout extends Vue {}
</script>
