<template>
  <div class="card">    
    <div class="card-body">
      <div>

      </div>        
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component({
  name: "ViewCustomer",
 props:['customer']
})
export default class ViewCustomers extends Vue {
  
}
</script>
