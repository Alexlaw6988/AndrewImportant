<template>
  <nav
    class="navbar navbar-expand-lg navbar-light rounded bg-gradient-light border-bottom py-0"
  >
    <h3>
      <a class="navbar-brand" href="#">
        {{ PageConfiguration.BrandName }}
      </a>
    </h3>
    <nav-bar></nav-bar>
  </nav>
</template>
<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import NavBar from "@/components/NavBar.vue";

@Component({
  name: "Header",
  components: { NavBar }
})
export default class Header extends Vue {}
</script>
