<template>
  <div id="app" >  
      <router-view/>   
  </div>
</template>
<style lang="sass">
  @import 'scss/site.scss';
  
</style>