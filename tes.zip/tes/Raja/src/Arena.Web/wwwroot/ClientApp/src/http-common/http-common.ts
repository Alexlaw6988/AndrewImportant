import axios from 'axios';

export const ApiBaseService  = axios.create({
  baseURL: process.env.BASE_URL,
  headers: {
    'Content-Type': 'application/json;charset=utf-8'
  }
})


