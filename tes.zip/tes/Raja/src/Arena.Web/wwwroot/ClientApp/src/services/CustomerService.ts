import { CustomerModel } from '@/types';
import { ApiUrls } from '@/constants/Api.urls';
import {ApiBaseService as HTTP} from '@/http-common/http-common'

export const CustomerService = {

    GetAllCustomers(){
        return HTTP.get(ApiUrls.GetAllCustomers);
    },
    GetCustomerById(Id : any ){
        return HTTP.get(`${ApiUrls.GetCustomerById}/${Id}`);
    },
    CreateCustomer(customer : CustomerModel){
        return HTTP.post(ApiUrls.CreateCustomer,customer);
    },
    UpdateCustomer(customer : CustomerModel){
        return HTTP.put(ApiUrls.UpdateCustomer,customer);
    },
    DeleteCustomer(customer : CustomerModel){
        return HTTP.put(ApiUrls.DeleteCustomer,customer);
    }
};
