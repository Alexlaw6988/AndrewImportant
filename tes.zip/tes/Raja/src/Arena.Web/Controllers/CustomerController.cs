﻿using Arena.Core.Entities;
using Arena.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Arena.Web.Controllers
{
    [Route("api/Customer")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerService _customerService;

        public CustomerController(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        [HttpGet("customers")]
        public async Task<IEnumerable<Customer>> GetCustomers()
        {
            return await _customerService.GetCustomersAsync();
        }

        [HttpGet("customer/{id}")]
        public async Task<ActionResult<Customer>> Get(int id)
        {
            return await _customerService.GetCustomerByIdAsync(id);
        }

        [HttpPost("createCustomer")]
        public async Task<ActionResult<Customer>> CreateCustomer(Customer customer)
        {
            if (!ModelState.IsValid)
            {

                return BadRequest();
            }

            return await _customerService.AddCustomerAsync(customer);
        }

        [HttpPut("updateCustomer")]
        public async Task<ActionResult<Customer>> UpdateCustomer(Customer customer)
        {
            if (!ModelState.IsValid)
            {

                return BadRequest();
            }

            return await _customerService.UpdateCustomerAsync(customer);
        }

        [HttpPut("deleteCustomer")]
        public async Task<ActionResult<Customer>> DeleteCustomer(Customer customer)
        {
            return await _customerService.DeleteCustomerAsync(customer);
        }
    }
}
