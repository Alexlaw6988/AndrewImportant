﻿using Arena.Core.Entities;
using Arena.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Arena.Web.Controllers
{
    [Route("api/Order")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrderController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpGet("orders")]
        public async Task<IEnumerable<Order>> GetOrders()
        {
            return await _orderService.GetOrdersAsync();
        }

        [HttpGet("order/{id}")]
        public async Task<ActionResult<Order>> Get(int id)
        {
            return await _orderService.GetOrderByIdAsync(id);            
        }

        [HttpPost("createOrder")]
        public async Task<ActionResult<Order>> CreateOrder(Order order)
        {
            if (!ModelState.IsValid){

                return BadRequest();
            }

            return await _orderService.AddOrderAsync(order);
        }

        [HttpPut("updateOrder")]
        public async Task<ActionResult<Order>> UpdateOrder(Order order)
        {
            if (!ModelState.IsValid)
            {

                return BadRequest();
            }

            return await _orderService.UpdateOrderAsync(order);
        }

        [HttpPut("deleteOrder")]
        public async Task<ActionResult<Order>> DeleteOrder(Order order)
        {
            if (!ModelState.IsValid)
            {

                return BadRequest();
            }

            return await _orderService.DeleteOrderAsync(order);
        }
    }
}
