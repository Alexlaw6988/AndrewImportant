﻿using System;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using Arena.Core.Interfaces;
using Arena.Core.Entities;

namespace Arena.Infrastructure.Data
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : BaseEntity
    {
        protected readonly ArenaContext DbContext;

        public Repository(ArenaContext dbContext)
        {
            DbContext = dbContext;
        }

        public async Task<int> GetCountAsync()
        {
            return await DbContext.Set<TEntity>().CountAsync();
        }

        public async Task<TEntity> GetByIdAsync(int id)
        {
            return await DbContext.Set<TEntity>().FindAsync(id);
        }

        public async Task<IEnumerable<TEntity>> GetAllAsync()
        {
            return await DbContext.Set<TEntity>().ToListAsync();
        }

        public async Task<TEntity> AddAsync(TEntity entity)
        {
            DbContext.Set<TEntity>().Add(entity);
            DateTime now = DateTime.UtcNow;
            entity.CreatedDate = now;
            entity.ModifiedDate = now;
            await DbContext.SaveChangesAsync();
            return entity;
        }

        public async Task<TEntity> UpdateAsync(TEntity entity)
        {
            DbContext.Entry(entity).State = EntityState.Modified;
            entity.ModifiedDate = DateTime.UtcNow;
            await DbContext.SaveChangesAsync();
            return entity;
        }

        public async Task<TEntity> DeleteAsync(TEntity entity)
        {
            DbContext.Set<TEntity>().Remove(entity);
            await DbContext.SaveChangesAsync();
            return entity;
        }
    }
}