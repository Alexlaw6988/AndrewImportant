﻿using System.Collections.Generic;
using Arena.Core.Entities;
using GenFu;

namespace Arena.Infrastructure.Data.Seed
{
    public static class CustomerSeedData
    { 
        public static Customer[] GetCustomers()
        {
            GenFu.GenFu.Configure<Customer>().Fill(x => x.Id, 0);
            GenFu.GenFu.Configure<Customer>().Fill(x => x.CreatedDate, CommonSeedData.Date);
            GenFu.GenFu.Configure<Customer>().Fill(x => x.ModifiedDate, CommonSeedData.Date);
            return A.ListOf<Customer>(100).ToArray();
        }
    }
}
