﻿using System;
using System.Collections.Generic;
using Arena.Core.Entities;
using GenFu;

namespace Arena.Infrastructure.Data.Seed
{
    public static class OrderSeedData
    { 
        public static Order[] GetOrders()
        {
            GenFu.GenFu.Configure<Order>().Fill(x => x.Id, 0);
            GenFu.GenFu.Configure<Order>().Fill(x => x.CustomerId).WithinRange(1,100);
            GenFu.GenFu.Configure<Order>().Fill(x => x.OrderNumber, CommonSeedData.Date.Ticks.ToString());
            GenFu.GenFu.Configure<Order>().Fill(x => x.Details).AsMusicGenreDescription();
            GenFu.GenFu.Configure<Order>().Fill(x => x.CreatedDate, CommonSeedData.Date);
            GenFu.GenFu.Configure<Order>().Fill(x => x.ModifiedDate, CommonSeedData.Date);
            return A.ListOf<Order>(100).ToArray();
        }
    }
}
